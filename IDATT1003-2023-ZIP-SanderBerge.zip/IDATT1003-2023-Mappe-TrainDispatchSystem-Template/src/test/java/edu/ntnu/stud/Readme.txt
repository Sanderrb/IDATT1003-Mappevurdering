Alle klassene som er testklasser (JUnit test klasser) plasserer du har.
Pass på at du har en testklasse for hver klasse du har laget.
Hver testklasse skal ha en testmetode for hver positive og negative test du ønsker å utføre på klassen.
Husk at test klassen og klassen som testes må ligge i samme pakke!

Når du har lest og forstått denne filen kan du velge å slette den.