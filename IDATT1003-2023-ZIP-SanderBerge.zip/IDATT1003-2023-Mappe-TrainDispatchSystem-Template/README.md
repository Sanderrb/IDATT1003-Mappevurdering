# Portfolio project IDATA1003 - 2023
This file uses Mark Down syntax. For more information see [here](https://www.markdownguide.org/basic-syntax/).

STUDENT NAME = "Sander Berge"  
STUDENT ID = "111678"

## Project description

[//]: # (In this project I have created a Train Dispatch apllication. The system handles numerous methods that allows the user to choose the preferred action. For example you can add train departures to a train table, view the table, change time ect.)

## Project structure

[//]: # (I have stored all the main classes in the main/java/edu/ntnu/stud part of the file. Her you can fint TrainDeparture, TrainDIpatchApp and TrainDispatchSystem. The test classes I have stores in test/java/edu/ntnu/stud. The only package I have used is "package edu.ntnu.stud;".)

## Link to repository

[//]: # (https://github.com/Sanderrb/IDATT1003-Mappevurdering)

## How to run the project

[//]: # (To run the project you just run the main method in vscode which I have used. You can find the main method in TrainDispatchApp.java. The output of the program shows a casesystem that allows the user to choose his option of what the user wants to do. You have several selections. You can thereafter choose your input in the console and interract with the application. The expected behaviour of the program is that it shows the case system and the user can interract without any problem. For example you can see a total traintable and add departures.)

## How to run the tests

[//]: # (I ran the test classes in the "Testing" selection on vscode. They all passed.)

## References

[//]: # (StardomEducation. (24.02.22). Java Output Lesson 02) Table Format. Gathered from: https://www.youtube.com/watch?v=M3LZlg_ggA4&ab_channel=StardomEducation )
